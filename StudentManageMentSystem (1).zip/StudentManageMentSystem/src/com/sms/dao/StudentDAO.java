package com.sms.dao;

import com.sms.model.Student;

public interface StudentDAO {
public void addStudents();
Student[] viewAllStudents();
Student viewStudent(int sno);
}
