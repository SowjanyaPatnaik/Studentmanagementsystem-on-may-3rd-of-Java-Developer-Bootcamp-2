package com.sms.dao.impl;

import java.util.Scanner;

import com.sms.dao.StudentDAO;
import com.sms.model.Student;

public class StudentDaoImpl implements StudentDAO {

	Scanner sc = new Scanner(System.in);
	public static Student[] addStudents;

	@Override
	public void addStudents() {
		// TODO Auto-generated method stub
		System.out.println("How many Students Wants to Join");
		int size = sc.nextInt();
		addStudents = new Student[size];

		for (int i = 0; i < addStudents.length; ++i) {
			System.out.println("Enter Student Number");
			int sno = sc.nextInt();
			System.out.println("Enter Student name");
			String sname = sc.next();
			System.out.println("Enter Student Address");
			String sadd = sc.next();
			Student stu = new Student(sno, sname, sadd);
			addStudents[i] = stu;
			System.out.println("Student Registred Successfully");
		}

	}

	@Override
	public Student[] viewAllStudents() {
		// TODO Auto-generated method stub
		return addStudents;
	}

	@Override
	public Student viewStudent(int sno) {
		// TODO Auto-generated method stub

		if (addStudents != null) {
			for (Student stu : addStudents) {
				if (stu.getSno() == sno) {
					return stu;

				}
			}
		} // end of if

		return null;
	}

}
