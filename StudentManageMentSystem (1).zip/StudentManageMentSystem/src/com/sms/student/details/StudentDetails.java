package com.sms.student.details;

import java.util.Scanner;

import com.sms.client.StudentClient;
import com.sms.dao.StudentDAO;
import com.sms.dao.impl.StudentDaoImpl;
import com.sms.model.Student;

public class StudentDetails {
	Scanner sc = new Scanner(System.in);
	StudentDAO daoImpl = new StudentDaoImpl();

	public void studentDetails() {

		while (true) {
			System.out.println("**********************************************");
			System.out.println("             1)viewAllStudents                                 ");
			System.out.println("              2)ViewStudent                                 ");
			System.out.println("              3)Back                                 ");

			System.out.println("**********************************************");

			System.out.println("Enter The Choice ?");
			int choice = sc.nextInt();
			switch (choice) {

			case 1:
				Student[] viewAllStudents = daoImpl.viewAllStudents();
				System.out.println("**********************************************");
				System.out.println(" SNO \t  SNAME \t            SADD            ");
				System.out.println("**********************************************");

				if (viewAllStudents != null) {
					for (Student stu : viewAllStudents) {
						if (stu != null)
							System.out.println(stu.getSno() + "\t" + stu.getSname() + "\t" + stu.getSadd());
					}
				} else {
					System.out.println("Records are not found");
				}

				break;

			case 2:
				System.out.println("Enter Student Number");
				Student stu = daoImpl.viewStudent(sc.nextInt());
				System.out.println("**********************************************");
				System.out.println(" SNO \t  SNAME \t            SADD            ");
				System.out.println("**********************************************");
				if (stu != null)
					System.out.println(stu.getSno() + "\t" + stu.getSname() + "\t" + stu.getSadd());
				else
					System.out.println("Student Record Not Found");
				break;
			case 3:
				StudentClient.main(null);
				break;

			default:
				System.out.println("Choose 1 to 3 Between");

			}

		} // end of while

	}// end of method

}
