package com.sms.admin.details;

import java.util.Scanner;

import com.sms.client.StudentClient;
import com.sms.dao.StudentDAO;
import com.sms.dao.impl.StudentDaoImpl;
import com.sms.model.Student;

public class AdminDetails {

	Scanner sc = new Scanner(System.in);
	StudentDAO daoImpl = new StudentDaoImpl();

	public void adminDetails() {
		while (true) {
			System.out.println("**********************************************");
			System.out.println("              1)AddStudent                                 ");
			System.out.println("              2)viewAllStudents                                 ");
			System.out.println("              3)ViewStudent                                 ");
			System.out.println("              4)Back                                 ");

			System.out.println("**********************************************");

			System.out.println("Enter The Choice ?");
			int choice = sc.nextInt();
			switch (choice) {
			case 1:
				daoImpl.addStudents();
				break;
			case 2:
				Student[] viewAllStudents = daoImpl.viewAllStudents();
				System.out.println("**********************************************");
				System.out.println(" SNO \t  SNAME \t            SADD            ");
				System.out.println("**********************************************");

				if (viewAllStudents != null) {
					for (Student stu : viewAllStudents) {
						if (stu != null)
							System.out.println(stu.getSno() + "\t" + stu.getSname() + "\t" + stu.getSadd());
					}
				} else {
					System.out.println("Records are not found");
				}

				break;

			case 3:
				System.out.println("Enter Student Number");
				Student stu = daoImpl.viewStudent(sc.nextInt());
				System.out.println("**********************************************");
				System.out.println(" SNO \t  SNAME \t            SADD            ");
				System.out.println("**********************************************");
				if (stu != null)
					System.out.println(stu.getSno() + "\t" + stu.getSname() + "\t" + stu.getSadd());
				else
					System.out.println("Student Record Not Found");
				break;
			case 4:
				StudentClient.main(null);
				break;

			default:
				System.out.println("Choose 1 to 4 Between");

			}

		} // end of while

	}// end of method

}
