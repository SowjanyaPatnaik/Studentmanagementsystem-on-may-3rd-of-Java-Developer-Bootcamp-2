package com.sms.client;

import java.util.Random;
import java.util.Scanner;

import com.sms.admin.details.AdminDetails;
import com.sms.dao.impl.StudentDaoImpl;
import com.sms.model.Student;
import com.sms.student.details.StudentDetails;

public class StudentClient {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
Scanner sc=new Scanner(System.in);
Random random=new Random();
		while(true)
		{
		System.out.println("*****************************************");
		System.out.println("             1)Admin              ");
		System.out.println("             2)Student              ");
		System.out.println("             3)Exit              ");
		System.out.println("*****************************************");
		System.out.println("Enter The Choice ");
		int choice=sc.nextInt();
		switch(choice)
		{
		case 1:
			System.out.println("Enter User Name");
			String uname=sc.next();
			System.out.println("Enter PassWord");
			String pass=sc.next();
			if(uname.equals("admin")&&pass.equals("admin@123"))
			{
			AdminDetails details=new AdminDetails();
			details.adminDetails();
			}
			else
				System.out.println("Invalid User");
			break;
		case 2:
			int y = random.nextInt(1000);  
			System.out.println(y);
			System.out.println("Enter User Name");
			String name=sc.next();
			
			System.out.println("Enter PassWord");
			int passw=sc.nextInt();	
			int k=0;
			
			for(Student stu : StudentDaoImpl.addStudents)
		{
			
			if(stu.getSname().equals(name)&&passw==y)
			{
				System.out.println("Welcome : "+stu.getSname());
				StudentDetails studetails=new StudentDetails();
				studetails.studentDetails();
				++k;
			}
			
		}
		if(k==0)
			System.out.println("Invalid User");
			
			
			
			break;
		case 3:
			System.out.println("Thx for Using App!");
			System.exit(0);
			default:
				System.out.println("Choose 1 to e Between");
		}
		
		
		}//end of while
	}

}
